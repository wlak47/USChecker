(() => {
  const intro = document.getElementById('startupIntro');
  const skip = document.getElementById('skipIntro');
  const key = 'wellauschecker_intro_seen_v1';
  const finish = () => {
    if (!intro || intro.classList.contains('intro-hidden')) return;
    intro.classList.add('intro-hidden');
    window.setTimeout(() => intro.remove(), 700);
  };
  try {
    if (localStorage.getItem(key) === '1') { intro.remove(); return; }
    localStorage.setItem(key, '1');
  } catch (_) {}
  skip?.addEventListener('click', finish);
  window.setTimeout(finish, 2600);
})();
